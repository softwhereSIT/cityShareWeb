Area destinada ao arquivos de backup do banco de dados
