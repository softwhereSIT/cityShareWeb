
        <link rel="stylesheet" href="css/style_add_beneficios.css"/>
        <link rel="stylesheet" href="css/style_standard_menu_cms.css"/>

            <?php include_once('menu_cms.php');?>
            <div id="dv-central">

                <div class="dv-txt-class">Add. Beneficios </div>
                <form>
                <div id="dv-preencher">
                    <input type="text" name="nome_beneficio"  placeholder="Nome Do Benefício" size="30" value="">
                    <textarea rows="8" cols="40" maxlength="500000" placeholder="Descrição" name="sobrefilme" value=""></textarea>
                    <input type="file" name="flefoto"/>
                    <input type="submit" name="btn_enviar" value="ENVIAR">
                </form>
                </div>
