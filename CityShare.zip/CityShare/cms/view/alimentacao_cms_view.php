<link rel="stylesheet" href="css/style_alimentacao.css">

<h2>Adm. Conteúdo do Site</h2>

<div id="dv-alimentacao-opcoes">
    <a href="index.php?controller=marketing&action=sete_motivos" title="7 Motivos"><div class="dv-alimentacao-item"><img src="" alt="7 Motivos" title="7 Motivos"> <h3>7 Motivos</h3></div></a>
    <a href="index.php?controller=marketing&action=parceiros" title="Parceiros"><div class="dv-alimentacao-item"><img src="" alt="Parceiros" title="Parceiros"> <h3>Parceiros</h3></div></a>
    <a href="index.php?controller=marketing&action=sobre_nos" title="Sobre Nós"><div class="dv-alimentacao-item"><img src="" alt="Sobre Nós" title="Sobre Nós"> <h3>Sobre Nós</h3></div></a>
    <a href="index.php?controller=marketing&action=duvidas_frquentes" title="Dúvidas Frequentes"><div class="dv-alimentacao-item"><img src="" alt="Dúvidas Frequentes" title="Dúvidas Frequentes"> <h3>Dúvidas Frequentes</h3></div></a>
    <a href="index.php?controller=marketing&action=fale_conosco" title="Fale Conosco"><div class="dv-alimentacao-item"><img src="" alt="Fale Conosco" title="Fale Conosco"> <h3>Fale Conosco</h3></div></a>
</div>
