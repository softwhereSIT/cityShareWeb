
    <link rel="stylesheet" href="css/style_aprovacoes.css"/>
    
            <div id="dv_titulo">
                <h1>Aprovações</h1>
            </div>



            <div id="dv_tabela">
                <div id="dv_linha_dados">

                    <div class="dv_dados">
                        <p class="texto"> Data e hora</p>
                    </div>

                    <div class="dv_dados">
                        <p class="texto"> Nome </p>
                    </div>

                    <div class="dv_dados">
                        <p class="texto"> Conteúdo</p>
                    </div>

                    <div class="dv_opcao">
                        <p class="texto"> Opções </p>
                    </div>
                </div>

                <!-- ***  REGISTROS DE APROVAÇÕES
                        <div id="dv_linha_dados">

                            <div class="dv_dados">
                                <p class="texto"> <?php ?> </p>
                            </div>

                            <div class="dv_dados">
                                <p class="texto"> <?php ?> </p>
                            </div>

                             <div class="dv_msg">
                                <p class="texto"> <?php ?> </p>
                            </div>

                            <div class="dv_opcao">
                                <p class="texto">  </p>
                            </div>
                        </div>

                  -->
            </div>
       