
    <link rel="stylesheet" href="css/style_Auditoria.css"/>

        <div id="dv_titulo">
            <h1>Auditoria</h1>
        </div>
        <div id="dv-busca-org">
            
             <h4>Buscar por: <input type="text" name="in-buscar" class="in-busca" >
             Organizar por:<select name="text" class="in-organizar">
                 <option>Data</option>
                 <option>Executor</option>
                 <option>Ação</option>
             </select></h4>

        </div>


        <div id="dv_tabela">
            <div id="dv_linha_dados">

                <div class="dv_dados">
                    <p class="texto"> Data e hora</p>
                </div>

                <div class="dv_dados">
                    <p class="texto"> Executor </p>
                </div>

                <div class="dv_dados">
                    <p class="texto"> Ação </p>
                </div>

                <div class="dv_opcao">
                    <p class="texto"> Vizualizar </p>
                </div>
            </div>

            <!-- ***  REGISTROS DE APROVAÇÕES
                        <div id="dv_linha_dados">

                            <div class="dv_dados">
                                <p class="texto"> <?php ?> </p>
                            </div>

                            <div class="dv_dados">
                                <p class="texto"> <?php ?> </p>
                            </div>

                             <div class="dv_dados">
                                <p class="texto"> <?php ?> </p>
                            </div>

                            <div class="dv_opcao">
                                <p class="texto">  </p>
                            </div>
                        </div>

                        -->
        </div>
