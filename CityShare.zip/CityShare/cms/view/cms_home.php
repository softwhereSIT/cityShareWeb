
        <link rel="stylesheet" href="css/style_cms_home.css"/>
                <div id="dv_nome">
                    <h1>Nome do Usuario</h1>
                </div>
                <div id="dv_foto">
                    <img src="img/user.png" />
                </div>

                <div id="dv_desc">
                    <p class="p_desc">Supervisora de Desenvolvimento</p>
                    <p class="p_desc">21/03/2017</p>
                </div>
                <div id="dv_logout">
                    <img src="img/exit.png" />
                    <p class="p_exit">Exit</p>
                </div>
           