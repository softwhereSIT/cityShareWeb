    <link rel="stylesheet" href="css/style_faleconosco_cms.css"/>

                <div id="dv_titulo">
                    <h1>Fale Conosco</h1>
                </div>
    
                <div id="dv_busca">
                    <div class="dv_input_legenda">
                        <label for="in-busca" class="legenda"> Busca por: </label>
                    </div>
                    
                    <div class="dv_input">
                        <input type="text" name="in-busca" class="in-busca" />
                    </div>
    
                    <div class="dv_input_legenda">
                        <label for="in-busca" class="legenda"> Organizar por: </label>
                    </div>
    
                    <div class="dv_input">
                        <select name="in-select" class="in-busca">
                            <option>Selecione ... </option>
    
                        </select>
                    </div>
    
                </div>
                
                <div id="dv_tabela">
                    <div id="dv_linha_dados">
                        
                        <div class="dv_dados">
                            <p class="texto"> Nome </p>
                        </div>
                        
                        <div class="dv_dados">
                            <p class="texto"> Email </p>
                        </div>
                        
                        <div class="dv_dados">
                            <p class="texto"> WhatsApp</p>
                        </div>
                        
                        <div class="dv_msg">
                            <p class="texto"> Mensagem </p>
                        </div>
                    
                        <div class="dv_opcao">
                            <p class="texto"> Opções </p>
                        </div>
                    </div>
                    
                    <!-- ***  REGISTROS DO FALE CONOSCO
                    <div id="dv_linha_dados">
                        
                        <div class="dv_dados">
                            <p class="texto"> <?php ?> </p>
                        </div>
                        
                        <div class="dv_dados">
                            <p class="texto"> <?php ?> </p>
                        </div>
                        
                        <div class="dv_dados">
                            <p class="texto"> <?php ?> </p>
                        </div>
                        
                        <div class="dv_msg">
                            <p class="texto"> <?php ?> </p>
                        </div>
                    
                        <div class="dv_opcao">
                            <p class="texto">  </p>
                        </div>
                    </div>
                    
                    -->
                </div>
            