
        <link rel="stylesheet" href="css/style_marketing.css"/>
        <link rel="stylesheet" href="css/style_standard_menu_cms.css"/>

    
    
            <div id="dv-central">
    
                <div class="dv-txt-class">Marketing </div>
                <div id="dv-opcoes">
                    <div id="dv-alimentacao">
                        <a href="index.php?controller=marketing&action=alimentacao" title="Marketing de Conteudo"><div id="dv-texto"> Alimentação de páginas</div></a>
                    </div>
                    <div id="dv-gerenciamento">
                        <div class="dv-texto"> Gerenciamento De Tema</div>
                    </div>
                </div>
            </div>

