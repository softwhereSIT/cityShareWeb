        <div id="dv-txt">
            <h2> Alimentação Do Site</h2>
        </div>

        <div id="dv-menucms">
            <div class="dv-menucms-class">
                <div id= "dv-img">
                     <img src="img/Categorize-50.png">
                </div>
                <div id="dv-txt-menu">Categoria</div>
            </div>
            <div class="dv-menucms-class">
                <div class="dv-img-class">
                    <img src="img/Picture-50.png">
                </div>
                <div class="dv-txt-menu">Banners</div>
            </div>
            <div class="dv-menucms-class">
                <div class="dv-img-class">
                    <img src="img/img_audi.png">
                </div>
                <div class="dv-txt-menu">Parceiros</div>
            </div>
            <div class="dv-menucms-class">
                <div class="dv-img-class">
                     <img src="img/Speech Bubble with Dots Filled-50.png">
                </div>
                <div class="dv-txt-menu">Sobre Nós</div>
            </div>

            <div class="dv-menucms-class">
                <div class="dv-img-class">
                    <img src="img/Happy-50.png">
                </div>
                <div class="dv-txt-menu">Benefícios</div>
            </div>
        </div>