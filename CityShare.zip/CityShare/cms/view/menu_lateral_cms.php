<div id="dv_nav">
    <div class="dv_itens_menu">
        <div class="dv_imagem">
            <a href="index.php?controller=cms&action=index" title="Home"><img src="img/img_home_black.png"></a>
        </div>
        <p class="p_legenda">Home</p>
    </div>
    
    <div class="dv_itens_menu">
       <div class="dv_imagem">
           <a href="index.php?controller=cms&action=auditoria" title="Auditoria"><img src="img/img_audi_black.png"></a>
        </div>
        <p class="p_legenda">Auditoria</p>
    </div>

    <div class="dv_itens_menu">
        <div class="dv_imagem">
            <a href="index.php?controller=cms&action=fale_conosco" title="Fale Conosco"><img src="img/img_flconosco_black.png"></a>
       </div>
       <p class="p_legenda">Fale conosco</p>
   </div>

   <div class="dv_itens_menu">
       <div class="dv_imagem">
           <a href="index.php?controller=cms&action=aprovacoes" title="Aprovações"><img src="img/img_aprovacoes_black.png"></a>
       </div>
       <p class="p_legenda">Aprovações</p>
   </div>

   <div class="dv_itens_menu">
       <div class="dv_imagem">
           <a href="index.php?controller=cms&action=marketing" title="Marketing"><img src="img/img_marketing_black.png"></a>
       </div>
       <p class="p_legenda">Marketing</p>
   </div>

   <div class="dv_itens_menu">
       <div class="dv_imagem">
           <img src="img/img_relatorio_black.png">
       </div>
       <p class="p_legenda">Relatórios</p>
   </div>

   <div class="dv_itens_menu">
       <div class="dv_imagem">
           <a href="index.php?controller=cms&action=funcionarios" title="Funcionarios"><img src="img/img_func_black.png"></a>
       </div>
       <p class="p_legenda">Funcionários</p>
   </div>

   <div class="dv_itens_menu">
       <div class="dv_imagem">
           <img src="img/img_tarifas_black.png">
       </div>
       <p class="p_legenda">Tarifas</p>
   </div>

</div>