<footer>
    <p id="rodape">
        Desenvolvido por Softwhere IT Solutions
    </p>
</footer>