<?php

class Controller_faleConosco{
    //Construtor
    public function __construct(){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){//especificar qual o tipo de requisição está vindo(post, get, ou nenhum)
            if($_GET['action'] == 'fale_conosco'){
                $this->Adicionar_faleConosco();//chama o método de adicionar nova mensagem
            }
        }else{//se não houver nenhuma requisição via post, get ou outro, irá fazer a requisição da classe FaleConosco
            require_once '../model/faleConosco_class.php';
        }
    }

    //Método que captura dados digitado pelo o usuário e chama o método 'Adicionar', da classe 'faleConosco}_class.php'
    public function Adicionar_faleConosco(){
        //Recuperando os textos digitados
        $nome = $_POST['in-nome'];
        $email = $_POST['in-email'];
        $celular = $_POST['in-whatsapp'];
        $tipoMsg = $_POST['in-rdo_tipoMsg'];
        $mensagem = $_POST['in-mensagem'];

        if($nome=="" or $email=="" or $celular=="" or $tipoMsg=="" or $mensagem==""){
            echo "<script> alert('** Há campos em branco! **');</script>";
        }else{
            $faleConosco_controller = new FaleConosco();

            $faleConosco_controller->setNome($nome);
            $faleConosco_controller->setEmail($email);
            $faleConosco_controller->setCelular($celular);
            $faleConosco_controller->setTipoMsg($tipoMsg);
            $faleConosco_controller->setMensagem($mensagem);

            //chamamos o método 'Adicionar', da classe 'faleConosco', passando o objeto 'faleConosco_controller' como parâmetro
            $faleConosco_controller::Adicionar($faleConosco_controller);
        }
    }

    //Método para excluir mensagem de fale conosco
    public function Excluir_faleConosco($id){
        $faleConosco_controller = new FaleConosco();
        $faleConosco_controller->Excluir($id);//chama o método excluir da classe 'FaleConosco' passando como parâmetro o ID
    }

    public function Editar_faleConosco(){}
    public function Atualizar_faleConosco(){}

    //Método que faz busca no banco de acordo com o  ID passado como parâmetro
    public function Buscar_faleConosco($id){
        $faleConosco_controller = new FaleConosco();//Instanciação do objeto da model
        $list = $faleConosco_controller->Buscar($id);//Para resgatar os atributos do objeto é precisso criar uma variável local para assim chamar o método da classe Contato, que busca no banco através do 'id'

        require_once ('../cms/view/fale_conosco_view.php');
    }

    //Método para selecionar todas as mensagens do fale conosco
    public function Listar_faleConosco(){
        $listaFaleConosco = new FaleConosco();//Instanciação do objeto da model
        return $listaFaleConosco->Listar();//chamando o método da classe 'FaleConosco', que seleciona todos os registros do banco. Retorna o resultado para quem o solicitar
}
}