<?php

class HomeController{
    
    public function loginUsuario(){
        
    }
    
    public function cadastrarUsuario(){
        
    }

    public function buscarVeiculo(){

    }

    public function listarVeiculos(){
        
    }
    
    
}

?>