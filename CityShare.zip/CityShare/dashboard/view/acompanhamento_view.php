<link rel="stylesheet" href="view/css/style_acompanhamento_dashboard.css">

<div id="dv-acompanhamento">
    <div id="dv-circ1" class="passo-circular"><img src="img/" alt="icon" title="icon"></div>
    <div id="dv-ret1" class="passo-retangular"></div>
    <div id="dv-circ2" class="passo-circular"></div>
    <div id="dv-ret2" class="passo-retangular"></div>
    <div id="dv-circ3" class="passo-circular"></div>
</div>