<link rel="stylesheet" href="view/css/style_home_dashboard.css">

<div id="dv-conteudo">
    <a href="index.php?controller=dashboard&action=meusDados" title="Meus Dados"><img id="img-dados" class="img-home-dash" src="view/img/dados.png"></a>
    <img src="view/img/forma-vd.png" id="img-forma-vd" class="img-opc">
    <a href="index.php?controller=dashboard&action=anuncios" title=Anúncios"><img id="img-anuncios" class="img-home-dash" src="view/img/anuncios.png"></a>
    <a href="index.php?controller=dashboard&action=acompanhamento" title="Acompanhamento"><img id="img-acompanhamento" class="img-home-dash" src="view/img/acompanhamento.png"></a>
    <a href="index.php?controller=dashboard&action=emprestimos" title="Empréstimos"><img id="img-emprestimos" class="img-home-dash" src="view/img/emprestimos.png"></a>
    <a href="index.php?controller=dashboard&action=historico" title="Histórico"><img id="img-historicos" class="img-home-dash" src="view/img/historico.png"></a>
    <img src="view/img/forma-cz.png" id="img-forma-cz" class="img-opc">
</div>