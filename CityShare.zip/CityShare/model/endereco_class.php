<?php

class endereco_class{
    private $idEndereco;
    private $idCliente;
    private $idEstado;
    private $idCidade;
    private $cep;
    private $rua;
    private $bairro;

    public function getIdEndereco(){
        return $this->idEndereco;
    }
    public function setIdEndereco($idEndereco){
        $this->idEndereco = $idEndereco;
    }
    public function getIdCliente(){
        return $this->idCliente;
    }
    public function setIdCliente($idCliente){
        $this->idCliente = $idCliente;
    }
    public function getIdEstado(){
        return $this->idEstado;
    }
    public function setIdEstado($idEstado){
        $this->idEstado = $idEstado;
    }
    public function getIdCidade(){
        return $this->idCidade;
    }
    public function setIdCidade($idCidade){
        $this->idCidade = $idCidade;
    }
    public function getCep(){
        return $this->cep;
    }
    public function setCep($cep){
        $this->cep = $cep;
    }
    public function getRua(){
        return $this->rua;
    }
    public function setRua($rua){
        $this->rua = $rua;
    }
    public function getBairro(){
        return $this->bairro;
    }
    public function setBairro($bairro){
        $this->bairro = $bairro;
    }
}