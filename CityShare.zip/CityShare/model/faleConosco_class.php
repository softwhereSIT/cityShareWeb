<?php

class FaleConosco{
    //Atributos
    private $id;
    private $nome;
    private $email;
    private $celular;
    private $tipoMsg;
    private $mensagem;

    //Construtor
    public function __construct(){
    }

    //Métodos acessores
    public function getId(){
        return $this->id;
    }
    public function setId($id){
        $this->id = $id;
        return $this;
    }
    public function getNome(){
        return $this->nome;
    }
    public function setNome($nome){
        $this->nome = $nome;
        return $this;
    }
    public function getEmail(){
        return $this->email;
    }
    public function setEmail($email){
        $this->email = $email;
        return $this;
    }
    public function getCelular(){
        return $this->celular;
    }
    public function setCelular($celular){
        $this->celular = $celular;
        return $this;
    }
    public function getTipoMsg(){
        return $this->tipoMsg;
    }
    public function setTipoMsg($tipoMsg){
        $this->tipoMsg = $tipoMsg;
        return $this;
    }
    public function getMensagem(){
        return $this->mensagem;
    }
    public function setMensagem($mensagem){
        $this->mensagem = $mensagem;
        return $this;
    }

    //Método para listar todas as mensagens do fale conosco
    public function Listar(){}

    //Método para adicionar mensagem
    public function Adicionar($nome, $email, $celular, $tipo, $mensagem){
        try{
            //Chamamos os metodo estático da classe db
            $db = Db::getInstance();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            //Chamamos a procedure e atribuimos seus valorem em ordem numerica
            $stmt = $db->prepare("call addFaleConosco(?,?,?,?,?)");
            $stmt->bindParam(1, $this->setNome($nome));
            $stmt->bindParam(2, $this->setEmail($email));
            $stmt->bindParam(3, $this->setCelular($celular));
            $stmt->bindParam(4, $this->setTipoMsg($tipo));
            $stmt->bindParam(5, $this->setMensagem($mensagem));

            // call the stored procedure
            $stmt->execute();

            //Mensagem para o usuário
            echo "<script> alert('Mensagem enviada!');</script>";

            // Redirecionando para area de funcionarios
            header("Location: index.php?controller=site&action=fale_conosco");

        }catch (PDOException $e){
            //Caso ocorra algum erro
            echo "<script> alert('Erro ao enviar mensagem!');</script>";
        }
    }

    //Método para editar mensagem
    public function Editar(){
        echo "<script> alert('Método editar!');</script>";
    }

    //Método para excluir mensagem
    public function Excluir($id){
        $db = Db::getInstance();
        $sttm = $db->prepare('call excluirFaleConosco(?)');
        $sttm->bindParam(1, $id);
        $sttm->execute();
        echo "<script> alert('Excluído com sucesso!');</script>";
    }

    public function Atualizar(){}

    //Método buscar, seleciona dados da tbl_faleconosco, de acordo com o ID
    public function Buscar($id){
        
    }
}