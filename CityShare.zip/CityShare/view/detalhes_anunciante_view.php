<section id="sec-det-anunciante">
    <span id="spn-det_anuncuante-fechar">x</span>
    <div id="dv-det_anunciante">
        <span id="spn-box_det_anunciante-fechar">x</span>
        <h2>Nome do veículo - Detalhes</h2>

        <div id="dv-img-anuncinate">
            <img src="view/img/car_0.png" alt="veiculo" title="Veiculo"/>
        </div>

        <!-- Atributos do veículo -->
        <div id="dv-attr-anunciante">
            <div id="dv-avaliacao-anunciante">
                <?php starRate(); ?>
            </div>
        </div>

    </div>

</section>