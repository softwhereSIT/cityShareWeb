        <link rel="stylesheet" type="text/css" href="view/css/style_duvidasFrequentes.css">
        

        <!-- Área principal de conteúdo do site-->
        <main id="main">

            <!--Caixa principal para as perguntas e a imagem da página-->
            <div id="dv-conteudo_duvidas_frequentes">

                <!--Título da página, para o usuário-->
                <h3>DÚVIDAS FREQUENTES</h3>

                <!-- Foi necessária a criação de duas caixas, para que quando a página fosse dimuinuída (tamanho) ela não quebrasse -->

                <!--Caixa para a imagem de interação com o usuário-->
                <div id="dv-icone_faq">
                    <div id="dv-icone">
                        <img src="view/img/icon_duvidasFrequentes.jpg" alt="Alguma dúvida?" title="Alguma dúvida?">
                    </div>
                </div>

                <!--Caixa para abrigar todas as perguntas e respostas frequentes -->
                <div id="dv-perguntas_respostas">

                    <!-- A classe "dv-blocos" refere-se a cada pergunta respectiva de sua resposta -->
                    <div class="dv-blocos">
                        <h4>Título da pergunta frequente?</h4>
                        <p>Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas
                            frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes
                            Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes</p>
                    </div>

                    <div class="dv-blocos">
                        <h4>Título da pergunta frequente?</h4>
                        <p>Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas
                            frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes
                            Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes</p>
                    </div>

                    <div class="dv-blocos">
                        <h4>Título da pergunta frequente?</h4>
                        <p>Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas
                            frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes
                            Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes Respostas frequentes</p>
                    </div>
                </div>
            </div>
        </main>