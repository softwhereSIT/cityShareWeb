<section id="sec-login-sup">
    <span id="spn-fechar">x</span>
    <div id="dv-login-sup">
        <span id="spn-box_login_sup-fechar">x</span>
        <h2>CITY SHARE</h2>
        
        <img src="view/img/logo_cs.png" alt="City Share" title="City Share">

        <form name="frm-sup" action="index.php?controller=site&action=login_superintendencia" method="post">
            <div id="dv-form-login-sup">

                <label id="lbl-sup-email" for="in-sup-email">E-MAIL</label>
                <input type="email" id="in-sup-email" name="in-sup-email" class="in-sup-campos" required>

                <label id="lbl-sup-senha" for="in-sup-senha">SENHA</label>
                <input type="password" id="in-sup-senha" name="in-sup-senha" class="in-sup-campos" required>

                <input type="submit" name="btn-login-sup" id="btn-login-sup" value="Entrar">
            </div>
        </form>

    </div>
    
</section>