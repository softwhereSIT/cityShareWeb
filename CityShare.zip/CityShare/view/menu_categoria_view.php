<section id="sec-menu_categorias">
    <h2>CATEGORIAS</h2>
    <nav id="menu_categorias">
        <ul id="lista_menu_categorias">
            <li><a href="index.php" title="Home">CARROS</a></li>
            <li><a href="#" title="7 Motivos">MOTOS</a></li>
            <li><a href="#" title="7 Motivos">BICICLETAS</a></li>
        </ul>
    </nav>
</section>

<script>
    // Get the modal
    var modal = document.getElementById('id01');

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>