<header>

    <!-- Centralização do Conteudo do cabeçalho-->
    <div id="dv-center_header">
    <!-- Logo da Empresa-->
        <div id="dv-logo">
            <a href="index.php?controller=site&action=index" title="Home"><img src="view/img/logo_city_share.png" alt="City Share - Logo" title="City Share Logo"/></a>
        </div>
        
        <!-- Menu de cor azul localizado ana area superior da pagina-->
        <nav id="menu_superior">
            <ul id="lista_menu_superior">
                <li><a href="index.php?controller=site&action=index" title="Home">HOME</a></li>
                <li><a href="index.php?controller=site&action=sete_motivos" title="7 Motivos">7 MOTIVOS</a></li>
                <li><a href="index.php?controller=site&action=parceiros" title="Parceiros">PARCEIROS</a></li>
                <li><a href="index.php?controller=site&action=sobre_nos" title="Sobre Nós">SOBRE NÓS</a></li>
                <li><a href="index.php?controller=site&action=fac" title="Dúvidas Frequentes">DÚVIDAS FREQUENTES</a></li>
                <li><a href="index.php?controller=site&action=fale_conosco" title="Fale Conosco">FALE CONOSCO</a></li>
            </ul>
        </nav>
    </div>


</header>
