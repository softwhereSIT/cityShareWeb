    <!-- Estilo da página -->
    <link rel="stylesheet" href="view/css/style_parceiros.css">

    <!-- Area principal de conteúdo do site-->
    <main>

        <!-- Pagina de Parceiros -->
         <h3>PARCEIROS</h3>

         <!-- Lista de Parceiros-->
         <div id="dv-parceiros_city">
            <div class="dv-parceiros_share">
                <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
            </div>
             <div class="dv-parceiros_share">
                 <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
             </div>
             <div class="dv-parceiros_share">
                 <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
             </div>
             <div class="dv-parceiros_share">
                 <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
             </div>
             <div class="dv-parceiros_share">
                 <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
             </div>
             <div class="dv-parceiros_share">
                 <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
             </div>

             <div class="dv-parceiros_share">
                 <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
             </div>
             <div class="dv-parceiros_share">
                 <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
             </div>
             <div class="dv-parceiros_share">
                 <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
             </div>
             <div class="dv-parceiros_share">
                 <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
             </div>
             <div class="dv-parceiros_share">
                 <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
             </div>
             <div class="dv-parceiros_share">
                 <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
             </div>
         </div>

    </main>