<footer>
    <div id="dv-conteudo_rodape">
        <!-- Area City Share -->
        <div id="dv-item_rodape_city_share" class="dv-item_conteudo_rodape">
            <!-- Lista contendo mapa do site localizado ana area City Share no rodapé-->

            <h3>CITY SHARE</h3>
            <nav id="menu_mapa_site">
                <ul id="lista_menu_mapa_site">
                    <li><a href="index.php" title="Home">HOME</a></li>
                    <li><a href="" title="7 Motivos">7 MOTIVOS</a></li>
                    <li><a href="" title="Sobre Nós">SOBRE NÓS</a></li>
                    <li><a href="" title="Dúvidas Frequentes">DÚVIDAS FREQUENTES</a></li>
                    <li><a href="" title="Fale Conosco">FALE CONOSCO</a></li>
                    <li><a id="link-superintendencia" href="#superintedencia" title="Superintendência">SUPERINTENDÊNCIA</a></li>
                </ul>
            </nav>
        </div>
        <!-- Area Etiquetas-->
        <div id="dv-item_rodape_etiquetas" class="dv-item_conteudo_rodape">
            <h3>ETIQUETAS</h3>
            <nav id="menu_etiqueta_site">
                <ul id="lista_menu_etiqueta_site">
                    <li><a href="index.php" title="Home">HOME</a></li>
                    <li><a href="#" title="7 Motivos">7 MOTIVOS</a></li>
                </ul>
            </nav>
        </div>

        <!-- Area Parceiros-->
        <div id="dv-item_rodape_parceiros" class="dv-item_conteudo_rodape">
            <h3>PARCEIROS</h3>

            <!-- Lista de Parceiros-->
            <div id="dv-parceiros">
                <div class="dv-parceiros-item">
                    <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
                </div>
                <div class="dv-parceiros-item">
                    <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
                </div>
                <div class="dv-parceiros-item">
                    <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
                </div>
                <div class="dv-parceiros-item">
                    <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
                </div>
                <div class="dv-parceiros-item">
                    <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
                </div>
                <div class="dv-parceiros-item">
                    <img src="view/img/parceiro_logo_w3c.png" alt="Parceiro" title="parceiro">
                </div>
            </div>
        </div>
        <!-- Area Mídias Sociais-->
        <div id="dv-item_rodape_midias" class="dv-item_conteudo_rodape">
            <h3>SHARE IT</h3>
            <a href="" title="Facebook"><span>B</span></a>
            <a href="" title="Twitter"><span>C</span></a>
            <a href="" title="Instagran"><span>E</span></a>
            <a href="" title="Google +"><span>D</span></a>
        </div>

        <!-- Copyrights do rodapé-->
        <div id="dv-copyright_rodape">
            <p>CNPJ: 00.000.000/0000-00 | Endereço: Rua Elton Silva, 905 - Centro - Jandira, São Paulo - 06600-025</p>
            <p>&copy; City Share 2015 - <?php echo(date ("Y"));?> | Todos os direitos reservados</p>
        </div>
    </div>
</footer>