    <link rel="stylesheet" href="view/css/style_sete_motivos.css">

    <?php include_once("view/login_modal_view.php");  ?>
    <main id="main_7_motivos">
        <div id="dv-mkt">
            <h2>VOCÊ TEM <strong>7</strong> MOTIVOS PARA UTILIZAR
                NOSSOS SERVIÇOS
            </h2>
        </div>

        <div class="dv-motivos-left">
            <div class="dv-item-motivo">
                <h2>TITULO</h2>

                <p>Texto</p>
            </div>
            <div class="dv-img-motivo">
                <img src="view/img" alt="motivo" title="motivo">
            </div>
        </div>

        <div class="dv-motivos-right">
            <div class="dv-item-motivo">
                <h2>TITULO</h2>

                <p>Texto</p>
            </div>
            <div class="dv-img-motivo">
                <img src="view/img" alt="motivo" title="motivo">
            </div>
        </div>

        <div class="dv-motivos-left">
            <div class="dv-item-motivo">
                <h2>TITULO</h2>

                <p>Texto</p>
            </div>
            <div class="dv-img-motivo">
                <img src="view/img" alt="motivo" title="motivo">
            </div>
        </div>

        <div class="dv-motivos-right">
            <div class="dv-item-motivo">
                <h2>TITULO</h2>

                <p>Texto</p>
            </div>
            <div class="dv-img-motivo">
                <img src="view/img" alt="motivo" title="motivo">
            </div>
        </div>

        <div class="dv-motivos-left">
            <div class="dv-item-motivo">
                <h2>TITULO</h2>

                <p>Texto</p>
            </div>
            <div class="dv-img-motivo">
                <img src="view/img" alt="motivo" title="motivo">
            </div>
        </div>

        <div class="dv-motivos-right">
            <div class="dv-item-motivo">
                <h2>TITULO</h2>

                <p>Texto</p>
            </div>
            <div class="dv-img-motivo">
                <img src="view/img" alt="motivo" title="motivo">
            </div>
        </div>

        <div class="dv-motivos-left">
            <div class="dv-item-motivo">
                <h2>TITULO</h2>

                <p>Texto</p>
            </div>
            <div class="dv-img-motivo">
                <img src="view/img" alt="motivo" title="motivo">
            </div>
        </div>
    </main>


