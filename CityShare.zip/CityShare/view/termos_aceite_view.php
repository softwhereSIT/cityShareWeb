<section id="sec-termo">
    <span id="spn-termo-fechar">x</span>
    <div id="dv-termos_uso">
        <span id="spn-box_termos-fechar">x</span>
        <h2>Termos de uso dos serviços City Share</h2>

        <p>
            Versão: < n >

            Responsável:  (nome/departamento)

            Santa Bárbara d'Oeste, < dia > de < mês > de < ano >

            1.	Objetivo

            Este documento tem por objetivo registrar, junto ao cliente e ao gerente do projeto, a conclusão e entrega final de cada fase ou do projeto como um todo.

            2.	Descrição do Produto Entregue

            Descrever o produto, serviço ou fase do projeto que foi completada e/ou entregue.>>


            3.	Resultados alcançados

            Apresentar a lista de resultados alcançados com o produto e/ou fase do projeto entregue.>>


            4.	Documentos relacionados ao aceite

            Aqui, vocês poderiam deixar os testes realizados e também registros da data de instalação do software no cliente>>





            Dados Finais

            Data de Início	: ______ / _______ / 20____

            Data de Término: ______ / _______ / 20_____




            6.	Declaração do Aceite

            Reconheço que  o projeto nome do projeto foi entregue satisfatoriamente, atendendo minhas expectativas e alcançando os resultados esperados. Sendo assim, nada mais é devido e damos por concluída o projeto.

                Data: ______/______/_______
                Cliente – nome – (área/departamento)
                        Data: ______/______/_______
                        (Gerente do Projeto) – (nome) – (área/departamento)

        </p>
    </div>

</section>