<?php
/**
 * Created by PhpStorm.
 * User: J. Guilherme
 * Date: 19/03/2017
 * Time: 01:05
 */

echo "test";

?>